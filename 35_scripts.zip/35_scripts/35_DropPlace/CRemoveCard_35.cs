﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class CRemoveCard_35 : MonoBehaviour, 
	IDropHandler {

	#region Fields

	[SerializeField]	protected int m_CurrentSize = 0;
	[SerializeField]	protected int m_MaximumSize = 2;

	protected RectTransform m_RectTransform;

	protected CGroupCard_35 m_Group;

	protected Image m_FilledImage;
    protected ParticleSystem Explode;
    //protected GameObject m_AdsImage;
    public Text CurrentSizeText;
    int CurrentSize = 3;


    public AudioSource UI;


	#endregion

	
	#region Main methods

      


	public virtual void Init()
	{
		// UI
		this.m_RectTransform = this.transform as RectTransform;
		// GROUP
		this.m_Group = GameObject.FindObjectOfType<CGroupCard_35>();
		// FILLD IMAGE
		this.m_FilledImage = this.GetComponent<Image>();
		// ADS IMAGE
		//this.m_AdsImage = this.transform.Find("AdsImage").gameObject;
		//this.m_AdsImage.SetActive (false);
		// CARDS
		this.m_CurrentSize = 0;
        //explode particle
        Explode = this.transform.GetChild(0).GetComponent<ParticleSystem>();
        

		// ADS
		//this.m_AdsSimple = GameObject.FindObjectOfType<CAdsSimple>();
	}

	public virtual void RemoveCard(CCard_35 card)
	{
		if (this.m_CurrentSize >= this.m_MaximumSize)
		{
          
		}
		else
		{
			this.RemoveCardSimple (card);

		}
	}

	public virtual void RemoveCardSimple(CCard_35 card)
	{
		card.transform.SetParent (this.m_RectTransform);	
		// TO
		var to = CGameSetting_35.ConvertScreenToLocal (this.m_RectTransform, card.lastPosition);
		// FROM
		var from = this.m_FilledImage.transform.localPosition;
		// MOVE
 		card.SetAnimation(CCard_35.EAnimation_35.DISAPPEAR);
		card.isDropped = true;
		card.Move (0.1f, to, from, 0.2f, () => {
			card.OnHandDropCard();
			card.SetActive (false);
			// RETURN CACHE
			this.m_Group.Set(card);
            // UPDATE SIZE
           this.m_CurrentSize += 1;
            CurrentSize -= 1;
            CurrentSizeText.text = CurrentSize.ToString();
            // play particles
            if(!Explode.isPlaying)
            Explode.Play();
			 
			this.SetSize(this.m_CurrentSize);

          
		});
        // CLICK SOUND
        UI.PlayOneShot(CGameSetting_35.instance.audioClips[8]);
	}

	/*public virtual void RemoveCardWithAds(CCard card)
	{
		if (this.m_AdsSimple == null)
			return;
		if (this.m_AdsSimple.canShowAds == false)
			return;
		this.m_AdsSimple.OnFinish.RemoveAllListeners();
		this.m_AdsSimple.OnFinish.AddListener(() => {
			this.RemoveCardSimple(card);
		});
		this.m_AdsSimple.Show();
	}
    */
	public virtual void Clear()
	{
		// CARDS
		this.m_CurrentSize = 0;
	
	}
    
	#endregion

	#region IPointer

	public void OnDrop (PointerEventData eventData)
	{
		// DROPPED
		if (this.m_Group != null 	
			&& this.m_Group.selectCard != null) // HAVE GROUP/ SELECT CARD
		{
			// REMOVE CARD
			this.RemoveCard (this.m_Group.selectCard);
		}
	}

	#endregion

	#region Getter && Setter

	public virtual void SetSize(int value)
	{
		// UPDATE SIZE
		this.m_CurrentSize = value;
        if (this.m_CurrentSize == m_MaximumSize)
        {
            this.m_FilledImage.color = new Color(255, 255, 255, 0.3f);
            CGameSetting_35.instance.remove = true;
            CurrentSizeText.transform.parent.gameObject.SetActive(false);
        }


    }

    #endregion

}
