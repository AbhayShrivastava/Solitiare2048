﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CGameSetting_35:MonoBehaviour {

    #region CONFIGS
    public GameObject hand;

    public AudioClip[] audioClips;
    //GameOver
    public GameObject GameOver;
    public bool gameOver;

    public AudioSource BG;
    private CBoard_35 cBoard;
    public bool NoOptions = false;
    public bool buttons=false;
    public bool remove=false;

	public  bool GAME_BUSY = false;

	public  int CARD_PER_COLUMN = 8;

	public  Vector2 CARD_SIZE = new Vector2(160f, 220f);
	
	public  int[] CARD_VALUES = new int[] {
			2, 
			4, 
			8, 
			16,
			32,
			64,
			128,
			256,
			512,
			1024,
			2048
		};

    public  Sprite[] CARD_SPRITES;

    public static CGameSetting_35 instance;

    #endregion

    
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
            Destroy(gameObject);

        cBoard = GetComponent<CBoard_35>();
    }



    private void Update()
    {
        if (buttons && remove)
        {
            cBoard.CheckHand();
        }
       //abhay
       

        if (NoOptions )
        {
            gameOver = true;


            BG.Stop();

        }
        
        if(gameOver)
        {

            StartCoroutine(Gameover());

        }
        else
            StopCoroutine(Gameover());








    }




    public void GameOverOnTimer()
    {
        gameOver = true;


    }
    
    IEnumerator  Gameover()
    {
        yield return new WaitForSeconds(0.5f);
        GameOver.SetActive(true);
        if (gameOver)
        {
            cBoard.ExplosionAllCards(null);
          
            
        }
        gameOver = false;
        this.enabled = false;  
    }


    /*#region LEVEL

	private string LEVEL_SAVE = "LEVEL_SAVE";
	public  int MAX_GAME_LEVEL = 1;
	public  int GAME_LEVEL
	{
		get 
		{ 
			var level = PlayerPrefs.GetInt(LEVEL_SAVE, 1) % MAX_GAME_LEVEL + 1; 
			return level;
		}
		set 
		{  
			PlayerPrefs.SetInt(LEVEL_SAVE, value);
			PlayerPrefs.Save();
		}
	}

    #endregion
    
    public static string SAVE_LOAD_NAME = "SAVE_GAME_0001";

    public static bool HasSaveGame()
    {
        return PlayerPrefs.HasKey(SAVE_LOAD_NAME);
    }

    public static void SaveGame(string listToStr)
    {
        // SAVE PREFABS
        PlayerPrefs.SetString(SAVE_LOAD_NAME, listToStr);
        PlayerPrefs.Save();
    }
    */


    #region ULTILITIES

    public static Vector2 ConvertScreenToLocal(RectTransform parent, Vector3 position)
	{
		var localPosition = Vector2.zero;
		RectTransformUtility.ScreenPointToLocalPointInRectangle(
            parent, 
            position, 
            Camera.main, 
            out localPosition);
		return localPosition;
	}

    #endregion
    
	
}
