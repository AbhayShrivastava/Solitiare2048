﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bettr_Encryption : MonoBehaviour
{
    public struct Encrypt
    {
        private float offset;
        private float value;

        public Encrypt(float value = 0)
        {
            offset = Random.Range(-1000, +1000);
            this.value = value + offset;
        }

        public float GetValue()
        {
            return value - offset;
        }

        public void Dispose()
        {
            offset = 0;
            value = 0;
        }

        public override string ToString()
        {
            return GetValue().ToString();
        }

        public static Encrypt operator +(Encrypt f1, Encrypt f2)
        {
            return new Encrypt(f1.GetValue() + f2.GetValue());
        }
    }

}

public class XOREncryption
{
    public static string encryptDecrypt(string input)
    {
        char[] key = { 'F', 'L', 'M', 'K', 'G', 'E','M' }; //Any chars will work, in an array of any size
        char[] output = new char[input.Length];

        for (int i = 0; i < input.Length; i++)
        {
            output[i] = (char)(input[i] ^ key[i % key.Length]);
        }

        return new string(output);
    }

}