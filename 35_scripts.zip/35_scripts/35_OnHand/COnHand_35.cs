﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class COnHand_35 : MonoBehaviour {

    #region FIELDS

    public Button swap;
    public Button Re;


	[Header("Configs")]
	[SerializeField]	protected int m_FirstCardDraw = 2;
	public int firstCardDraw 
	{ 
		get { return this.m_FirstCardDraw; }
		set { this.m_FirstCardDraw = value; }
	}
	[SerializeField]	protected float m_WidthOffset = 140f;
	[SerializeField] 	protected Transform m_CardContainer;
	protected LayoutGroup m_LayoutGroup;
	protected Transform m_FirstCard;
	[SerializeField] 	protected List<CCard_35> m_OnHandCards;
	public List<CCard_35> onHandCard 
	{ 
		get { return this.m_OnHandCards; }
		protected set { this.m_OnHandCards = value; }
	}

	 public CCard_35 m_CardPrefab;

	protected CGroupCard_35 m_Group;
	protected CBoard_35 m_Board;

	protected WaitForFixedUpdate m_WaitFixedUpdate = new WaitForFixedUpdate();

    public AudioSource UI;

    #endregion

    #region Implementation Monobehaviour

    private void Update()
    {
        if(int.Parse(m_Board.MaximumNoRE.ToString())<1)
        {
            Re.interactable = false;
            
        }
        else
        {
            Re.interactable = true;
            

        }
        if (int.Parse(m_Board.MaximumNoswap.ToString()) < 1)
        {
            swap.interactable = false;

        }
        else
        {
            swap.interactable = true;


        }

        if (!Re.interactable && !swap.interactable&&GetAvailableCard().cardType!=CCard_35.ECardType_35.SPECIAL)
        { 
            CGameSetting_35.instance.buttons = true;
        }  
        else
            CGameSetting_35.instance.buttons = false;

      

       


    }

    #endregion

    #region Main methods

    public virtual void Init()
	{
		// UI
		this.m_CardContainer = this.transform.Find("CardContain");
		this.m_LayoutGroup = this.m_CardContainer.GetComponent<LayoutGroup>();
		this.m_LayoutGroup.enabled = true;
		this.m_FirstCard = this.m_CardContainer.Find("FirstCard");
		// CARDS
		this.m_OnHandCards = new List<CCard_35>();
		// GROUP
		this.m_Group = GameObject.FindObjectOfType<CGroupCard_35>();
		// BOARD
		this.m_Board = GameObject.FindObjectOfType<CBoard_35>();
		
		// DRAW
		this.OnDrawCards();




	}

	public virtual void Clear()
	{
		// CARDS
		for (int i = 0; i < this.m_OnHandCards.Count; i++)
		{
			this.m_OnHandCards[i].SetActive(false);
			this.m_OnHandCards[i].activeCard = false;
			this.m_OnHandCards[i].isDropped = false;
			this.m_Group.Set(this.m_OnHandCards[i]);
		}
		this.m_OnHandCards.Clear();
		this.m_OnHandCards.TrimExcess();
	}

	public virtual void OnDrawCards()
	{
		// DRAW CARDS
		while (this.m_OnHandCards.Count < this.m_FirstCardDraw)
		{
			var random = Random.Range(0, 6);
			var value = CGameSetting_35.instance.CARD_VALUES[random];
			var type = COnHand_35.RandomCardType(); // CCard.ECardType.NUMBER;
			var card = this.DrawCard (value, type);
			this.OnHandACard(card);
			card.SetActive (true);
            card.GetComponent<Image>().raycastTarget = true;
		}
		// FIRST ACTIVE CARD
		this.ActiveFirstCard();
	}

	public virtual void OnReDrawCards()
	{

        //sound
        UI.PlayOneShot(CGameSetting_35.instance.audioClips[7]);

		// CLEAR
		for (int i = 0; i < this.m_OnHandCards.Count; i++)
		{
			this.m_OnHandCards[i].SetActive(false);
			this.m_OnHandCards[i].activeCard = false;
			this.m_OnHandCards[i].isDropped = false;
			this.m_Group.Set(this.m_OnHandCards[i]);
            
		}
		this.m_OnHandCards.Clear();
		this.m_OnHandCards.TrimExcess();
		// DRAW CARDS
		this.OnDrawCards();
        m_Board.MaximumNoRE = new Bettr_Encryption.Encrypt(0);
        m_Board.RE_ENCRYPT = XOREncryption.encryptDecrypt(m_Board.RE_ENCRYPT);
        m_Board.RE_ENCRYPT = (0).ToString();
        m_Board.RE_ENCRYPT = XOREncryption.encryptDecrypt(m_Board.RE_ENCRYPT);

    }

    public virtual CCard_35 DrawCard(int value, CCard_35.ECardType_35 type)
	{
       
        CCard_35 card = this.m_Group.Get();
		if (card == null)
		{
			card = Instantiate(this.m_CardPrefab);
		}
		card.Init();
		card.Clear();
		card.Setup(value, type, this);
		card.gameObject.SetActive(true);
		// UI
		this.m_FirstCard.gameObject.SetActive (false);
		// RETURN
		return card;
	}

	public virtual void OnHandACard(CCard_35 card)
	{
		this.m_LayoutGroup.enabled = false;
		// SET UP
		card.transform.SetParent (this.m_CardContainer);
		card.transform.localPosition = this.m_FirstCard.transform.localPosition;
		card.transform.localRotation = Quaternion.identity;
		card.transform.localScale = Vector3.one;
		card.transform.SetSiblingIndex(0);
		// ANIMATING
		this.AnimatingACard ();
		// ADD
		this.m_OnHandCards.Add (card);
        // CLICK SOUND
        
	}

	public virtual void OnHandACardImmediate(CCard_35 card)
	{
		this.m_LayoutGroup.enabled = true;
		// SET UP
		card.transform.SetParent (this.m_CardContainer);
		card.transform.localPosition = this.m_FirstCard.transform.localPosition;
		card.transform.localRotation = Quaternion.identity;
		card.transform.localScale = Vector3.one;
		card.transform.SetSiblingIndex(0);
		card.gameObject.SetActive(true);
		// ADD
		this.m_OnHandCards.Add (card);
	}

	protected void AnimatingACard()
	{
		if (this.m_OnHandCards.Count < 1)
		{
			this.m_LayoutGroup.enabled = true;
			return;
		}
		var card = this.GetLastCard();
		var to = this.m_FirstCard.transform.localPosition;
		var from = to;
		from.x += this.m_WidthOffset;
       // this.m_LayoutGroup.enabled = true;
        card.Move(0.1f, 
			to, from, 
			0.2f, 
			() => {
                this.m_LayoutGroup.enabled = true;
            });
    }

	public virtual void DropCard(CCard_35 card)
	{
		// REMOVE ON HAND
		this.m_OnHandCards.Remove (card);
		// DRAW A NEW CARD
		this.OnDrawCards();
	}

	public virtual void ActiveFirstCard()
	{
		// FIRST ACTIVE CARD
		for (int i = 0; i < this.m_OnHandCards.Count; i++)
		{
			if (i > 0)
			{
				this.m_OnHandCards[i].SetAnimation (CCard_35.EAnimation_35.APPEAR);
				this.m_OnHandCards[i].activeCard = false;
			}
			else
			{
				this.m_OnHandCards[i].activeCard = true;
			}
		}
	}

	#endregion

	#region Getter && Setter

	public virtual CCard_35 GetAvailableCard()
	{
		// FIRST ACTIVE CARD
		for (int i = 0; i < this.m_OnHandCards.Count; i++)
		{
			if (this.m_OnHandCards[i].activeCard)
				return this.m_OnHandCards[i];
		}
		return null;
	}

	public virtual CCard_35 GetLastCard()
	{
		if (this.m_OnHandCards.Count < 1)
			return null;
		return this.m_OnHandCards [this.m_OnHandCards.Count - 1];
	}

	#endregion

	#region Getter && Setter

	public static CCard_35.ECardType_35 RandomCardType()
	{
		var random = Random.Range (0, 100);
		// 95 => NUMBER
		// 5 => BOMB
		if (random <= 90)
		{
           
			return CCard_35.ECardType_35.NUMBER;
		}
        else if (random>90&&random<95)
        {
            return CCard_35.ECardType_35.SPECIAL;
        }
		else
		{
            
			return CCard_35.ECardType_35.BOMB;
		}
		// return CCard.ECardType.NUMBER;
	}

    #endregion


    #region SwapButton

    public void Swap()
    {
        UI.PlayOneShot(CGameSetting_35.instance.audioClips[9]);

        m_Board.MaximumNoswap = new Bettr_Encryption.Encrypt(0);
        m_Board.SWAP_ENCRYPT = XOREncryption.encryptDecrypt(m_Board.SWAP_ENCRYPT);
        m_Board.SWAP_ENCRYPT = (0).ToString();
        m_Board.SWAP_ENCRYPT = XOREncryption.encryptDecrypt(m_Board.SWAP_ENCRYPT);

        GetAvailableCard().transform.SetAsFirstSibling();
            m_OnHandCards.Reverse();
            this.ActiveFirstCard();
        




    }

    #endregion


}
