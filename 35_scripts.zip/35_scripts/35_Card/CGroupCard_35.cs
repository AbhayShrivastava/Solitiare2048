﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CGroupCard_35 : MonoBehaviour {

	#region Fields

	public CCard_35 selectCard;

	protected Queue<CCard_35> cache = new Queue<CCard_35>();

	protected Transform m_Transform;

	#endregion

	#region Implementation Monobehaviour

	protected virtual void Awake()
	{
		this.m_Transform = this.transform;
	}

	#endregion

	#region Object pool
	
	public virtual CCard_35 Get()
	{
		if (this.cache.Count == 0)
			return null;
		return this.cache.Dequeue();
	}

	public virtual void Set(CCard_35 card)
	{
		this.cache.Enqueue (card);
		// SET PARENT
		card.transform.SetParent (this.m_Transform);
		card.transform.localPosition = Vector3.zero;
		card.transform.localRotation = Quaternion.identity;
		card.transform.localScale = Vector3.one;
	} 

	#endregion

}
