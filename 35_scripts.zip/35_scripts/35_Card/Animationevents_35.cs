﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animationevents_35 : MonoBehaviour {


    public GameObject Text;

    

    void ActivateText()
    {
        Text.SetActive(true);
        this.gameObject.SetActive(false);
       

    }
}
